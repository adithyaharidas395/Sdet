package PageObjects;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {
	
	WebDriver ldriver;
	WebDriver driver;
	
	public HomePage(WebDriver rdriver)
	{
		ldriver=rdriver;
		PageFactory.initElements(rdriver, this);
	}
	@FindBy(xpath="//*[@id=\"container\"]/div/div[1]/div[1]/div[2]/div[1]/div/a[1]/img")
	WebElement log;
	
	@FindBy(xpath="/html/body/div[2]/div/div/button") //for clicking contact
	WebElement closepop;
	
	@FindBy(name="q")
	WebElement searchbar;
	
	public void CheckFlip() //logo check
	{
		log.isDisplayed();
		
	}
	
	public void ClickOnClosePopUp() //closing pop up at the start
	{
		closepop.click();
	}
	public void ClickSearchBar(String product) //performing search
	{
		searchbar.click();
		searchbar.sendKeys(product);
		searchbar.sendKeys(Keys.ENTER);
	}
	

}
