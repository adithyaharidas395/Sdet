package TestCases;

import java.util.List;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.openqa.selenium.WebElement;

import PageObjects.HomePage;
import PageObjects.ResultPage;


public class ScenarioOne extends BaseClass{
	
	@Test
	public void FirstTest() throws InterruptedException
	{
		HomePage hp=new HomePage(driver); //object of homepage
		ResultPage rp=new ResultPage(driver); //object of result page
		hp.ClickOnClosePopUp();
		hp.CheckFlip();
		hp.ClickSearchBar("iphone 14");
		Thread.sleep(3000);		
		count();
		rp.ClickOnProduct();
		Thread.sleep(3000);
		Assert.assertEquals(driver.getTitle(), "APPLE iPhone 14 ( 128 GB Storage ) Online at Best Price On Flipkart.com");		
		
		
	
	
		
	}

}
