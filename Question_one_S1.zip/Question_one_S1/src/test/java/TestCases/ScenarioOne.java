package TestCases;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.Test;

import PageObjects.ContactPage;
import PageObjects.HomePage;


public class ScenarioOne extends BaseClass{
	
	@Test
	public void FirstTest() throws InterruptedException
	{
		HomePage hp=new HomePage(driver); //object of homepage
		
		hp.ClickContactPage();
		Assert.assertEquals(driver.getTitle(), "Contact | Automation Panda");		
		scroll();
		timeout();
		
		ContactPage cp=new ContactPage(driver); //object of contact page
		cp.EnterName("Adithya"); //sending name
		cp.EnterEmail("adithh@virtusa.com"); //sending email
		cp.EnterMsg("Hello"); //sending message
		cp.submitButton(); //clicking on submit 
		
		String text=driver.findElement(By.xpath("//*[@id=\"contact-form-success-header\"]")).getText(); 
		Assert.assertEquals(text,"Your message has been sent");
	}

}
