package TestCases;

import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;

public class BaseClass {
	WebDriver driver;
	
	@BeforeSuite
	public void setup() //intial setup
	{
		System.setProperty("webdriver.http.factory", "jdk-http-client");
		System.setProperty("webdriver.edge.driver","C:\\Users\\ADITHYAH\\Downloads\\edgedriver_win64\\msedgedriver.exe");
		driver=new EdgeDriver();
		driver.get("https://automationpanda.com/2021/12/29/want-to-practice-test-automation-try-these-demo-sites/");
	}
	
	@AfterClass
	public void teardown() //close the browser 
	{
		driver.quit();
	}
	public void scroll() //to scroll down
	{
		JavascriptExecutor jsExecutor = (JavascriptExecutor)driver;
		jsExecutor.executeScript("window.scrollBy(0,500)","");
	}
	
	public void timeout()
	{
		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
	}

}
