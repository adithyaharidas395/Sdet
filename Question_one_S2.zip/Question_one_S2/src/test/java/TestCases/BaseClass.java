package TestCases;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;

public class BaseClass {
	WebDriver driver;
	
	@BeforeSuite
	public void setup() //intial setup
	{
		System.setProperty("webdriver.http.factory", "jdk-http-client");
		System.setProperty("webdriver.edge.driver","C:\\Users\\ADITHYAH\\Downloads\\edgedriver_win64\\msedgedriver.exe");
		driver=new EdgeDriver();
		driver.get("https://www.flipkart.com/"); //url
	}
	
	@AfterClass
	public void teardown() //close the browser 
	{
		driver.quit();
	}
	
	public void timeout()
	{
		 WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
	}
	public void count()
	{
		List <WebElement> ele=driver.findElements(By.xpath("//*[@id=\"container\"]/div/div[3]/div[1]/div[2]/div[2]/div/div/div"));
		for(int i=0;i<ele.size();i++)
		{
		
			System.out.println(i);
		}
		
	}

}
