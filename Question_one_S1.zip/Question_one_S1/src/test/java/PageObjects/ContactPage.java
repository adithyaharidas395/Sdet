package PageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ContactPage {
	
	WebDriver ldriver;

	
	public ContactPage(WebDriver rdriver)
	{
		ldriver=rdriver;
		PageFactory.initElements(rdriver, this);
	}
	
	@FindBy(id="g3-name") //for name field
	WebElement name;
	
	@FindBy(id="g3-email") //for email field
	WebElement email;
	
	@FindBy(id="contact-form-comment-g3-message") //for message fiedl
	WebElement message;
	
	@FindBy(xpath="//*[@id=\"contact-form-3\"]/form/div/div[4]/button/strong") //for submit button
	WebElement submit;
	
	public void EnterName(String uname) 
	{
		name.sendKeys(uname);
	}
	
	public void EnterEmail(String eid) 
	{
		email.sendKeys(eid);
	}
	
	public void EnterMsg(String msg)
	{
		message.sendKeys(msg);
	}
	public void submitButton()
	{
		submit.click();
	}
	
	
	
	
	
	
	
	
	
	
	

}
